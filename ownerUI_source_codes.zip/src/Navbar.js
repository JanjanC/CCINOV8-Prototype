export default function Navbar() {
    return <nav className="nav">
        <a href="/" className="site-title">PPark</a>
        <ul>
            <li>
                <a href="/overview">Overview</a>
            </li>
            <li>
                <a href="/bookings">Bookings</a>
            </li>
            <li>
                <a href="/Support">Support</a>
            </li>
        </ul>
    </nav>
}